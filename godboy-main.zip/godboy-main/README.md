pkg update && pkg upgrade

pkg install git

pkg install python2

pkg install nodejs

git clone https://github.com/kinarworo/godboy

cd godboy

python2 godboy.py
